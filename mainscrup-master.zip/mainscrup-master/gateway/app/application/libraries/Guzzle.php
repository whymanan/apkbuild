<?php
  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

  class Guzzle {

    public function __construct()
    {
        require 'vendor/autoload.php';
    }

  }
?>
