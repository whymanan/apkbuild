
<?php

  include('layout/css.php');
    echo $main_content;
  include('layout/footer.php');

?>
