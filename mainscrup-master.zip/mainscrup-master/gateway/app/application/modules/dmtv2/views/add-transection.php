<input type="hidden" name="beneficiaryid" value="<?php echo $beneficiary->ba_primary; ?>">
<input type="hidden" name="mobile" value="<?php echo $beneficiary->beneficiary_mobile; ?>">
<input type="hidden" name="beneficiary_account_number" value="<?php echo $beneficiary->beneficiary_account_number; ?>">
<input type="hidden" name="beneficiary_ifsc" value="<?php echo $beneficiary->beneficiary_ifsc; ?>">
