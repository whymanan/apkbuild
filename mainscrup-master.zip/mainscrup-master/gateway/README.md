# emopay
Emo PAY Admin Dashboard

IP: 148.66.132.29
Host: emopay.co.in
FTP-user: omie@emopay.co.in
FTP-password: Jk0,r!wE2}3y
